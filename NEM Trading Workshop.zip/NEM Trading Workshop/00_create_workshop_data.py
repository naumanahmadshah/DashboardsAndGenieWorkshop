# Databricks notebook source
# MAGIC %md
# MAGIC # NEM Trading Desk Workshop: create the workshop data
# MAGIC
# MAGIC This notebook builds everything you need for the **Dashboards, Genie and Apps** workshop: the catalog `nem_workshop`, the
# MAGIC schema `nem_workshop.trading_desk` and **13 tables** of synthetic data that look and behave like the data on a National
# MAGIC Electricity Market (NEM) trading desk.
# MAGIC
# MAGIC | Layer | Tables | Styled on |
# MAGIC |---|---|---|
# MAGIC | Market data (AEMO style) | `aemo_region`, `aemo_generating_unit`, `aemo_dispatch_region`, `aemo_unit_dispatch` | AEMO MMS dispatch prices, regional demand, unit SCADA output and generator registration |
# MAGIC | Trading and risk (ETRM style) | `etrm_book`, `etrm_counterparty`, `etrm_trade`, `etrm_forward_curve`, `etrm_trade_valuation`, `etrm_trade_settlement` | An Allegro-style energy trading and risk management (ETRM) system |
# MAGIC | Dashboard-ready (gold) | `gold_market_daily`, `gold_book_pnl_daily`, `gold_counterparty_exposure_daily` | Daily summaries built from the tables above |
# MAGIC
# MAGIC ### How to run it
# MAGIC 1. In the top right, connect to **Serverless** compute (or a cluster on Databricks Runtime 14.3 LTS or above).
# MAGIC 2. Click **Run all**. There is nothing to fill in. It takes about 3 to 5 minutes, and the last cell prints a summary of the tables.
# MAGIC
# MAGIC The notebook is written for your own workshop workspace, where you are an admin. It creates the catalog and schema for you.
# MAGIC Re-running is safe: it only replaces the 13 tables listed above.
# MAGIC
# MAGIC > **All data is synthetic.** Power stations, counterparties, books and traders are fictional. The patterns (the solar
# MAGIC > "duck curve", evening peaks, price spikes, negative prices, hedge books, mark-to-market) are realistic, but no number is
# MAGIC > real market or company data.

# COMMAND ----------

# Step 1: where the data goes. Every attendee uses the same names in their own workspace, so the dashboard, Genie and app
# steps can use exactly the same table names.
CATALOG = "nem_workshop"
SCHEMA = "trading_desk"
HISTORY_DAYS = 365
SEED = 42
# Instructor (optional): pin the day after the last day of data, for example "2026-11-07", so every run produces identical
# numbers. Leave blank to end the data at midnight today, which keeps questions such as "last month" natural.
DEFAULT_END_DATE = ""

# COMMAND ----------

# Step 2: create the catalog and schema.
try:
    spark.sql(f"CREATE CATALOG IF NOT EXISTS `{CATALOG}` COMMENT 'NEM trading desk workshop: synthetic AEMO-style market data and Allegro-style ETRM data.'")
    spark.sql(
        f"CREATE SCHEMA IF NOT EXISTS `{CATALOG}`.`{SCHEMA}` COMMENT "
        "'NEM trading desk workshop: synthetic AEMO-style market data and Allegro-style ETRM trading, valuation and settlement data.'"
    )
except Exception as e:
    raise PermissionError(
        f"Could not create {CATALOG}.{SCHEMA}. This notebook expects your own workshop workspace, where you are an admin. "
        f"If you are in a shared workspace, ask your instructor to create the catalog {CATALOG} and give you CREATE SCHEMA on it.\n{e}"
    )
spark.sql(f"USE CATALOG `{CATALOG}`")
spark.sql(f"USE SCHEMA `{SCHEMA}`")
try:
    spark.conf.set("spark.sql.session.timeZone", "UTC")
except Exception:
    pass
print(f"Tables will be written to {CATALOG}.{SCHEMA}")

# COMMAND ----------

# Step 3: reference data (regions, generating units, books, counterparties) and helpers.
import math
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

rng = np.random.default_rng(SEED)

MARKET_TZ = ZoneInfo("Australia/Brisbane")  # NEM market time is AEST (UTC+10) all year, with no daylight saving
END_DATE = date.fromisoformat(DEFAULT_END_DATE) if DEFAULT_END_DATE else datetime.now(MARKET_TZ).date()  # exclusive: data runs to midnight at the start of this day
START_DATE = END_DATE - timedelta(days=HISTORY_DAYS)
AS_OF_DATE = pd.bdate_range(END_DATE - timedelta(days=7), END_DATE - timedelta(days=1))[-1].date()  # last business day
MARKET_FLOOR = -1000.0
# Market price cap by financial year (ending 30 June), from the AEMC schedule of reliability settings
MARKET_PRICE_CAP = {2025: 17500.0, 2026: 20300.0, 2027: 23200.0}
CAP_STRIKE = 300.0
DISCOUNT_RATE = 0.0425

REGIONS = pd.DataFrame(
    [
        ("NSW1", "New South Wales", "NSW", "Sydney West 330 kV", -33.80, 150.87, True),
        ("QLD1", "Queensland", "QLD", "South Pine 275 kV", -27.35, 152.95, True),
        ("VIC1", "Victoria", "VIC", "Thomastown 66 kV", -37.69, 145.02, True),
        ("SA1", "South Australia", "SA", "Torrens Island 66 kV", -34.80, 138.52, True),
        ("TAS1", "Tasmania", "TAS", "George Town 220 kV", -41.10, 146.83, False),
    ],
    columns=["region_id", "region_name", "state_code", "reference_node", "latitude", "longitude", "has_exchange_futures"],
)
STATE = dict(zip(REGIONS.region_id, REGIONS.state_code))

# Market model settings per region: underlying demand, seasonal swing, installed rooftop / wind / utility solar capacity,
# solar noon in market time, day-length swing, typical price, and how easily the region sees negative prices.
REGION_MODEL = {
    "NSW1": dict(demand=8900, summer=0.08, winter=0.09, rooftop=7600, wind=2600, solar=4300, noon=12.05, daylen=2.0, price=112, neg_z=-1.30, kappa=0.47, thermal=11200),
    "QLD1": dict(demand=7500, summer=0.12, winter=0.02, rooftop=6600, wind=1600, solar=5200, noon=11.85, daylen=1.4, price=104, neg_z=-1.00, kappa=0.47, thermal=10200),
    "VIC1": dict(demand=5900, summer=0.05, winter=0.12, rooftop=5200, wind=4400, solar=1700, noon=12.35, daylen=2.4, price=90, neg_z=-0.80, kappa=0.47, thermal=6400),
    "SA1": dict(demand=1650, summer=0.09, winter=0.08, rooftop=2300, wind=2600, solar=750, noon=12.70, daylen=2.2, price=110, neg_z=-0.62, kappa=0.47, thermal=3000),
    "TAS1": dict(demand=1150, summer=0.00, winter=0.15, rooftop=380, wind=650, solar=0, noon=12.40, daylen=3.0, price=74, neg_z=-1.90, kappa=0.38, thermal=2700),
}

GENERATING_UNITS = pd.DataFrame(
    [
        # duid, station, region, fuel, technology, classification, dispatch type, MW, MWh storage, min stable MW, SRMC, tCO2e/MWh, ownership, year, lat, lon
        ("WOLRG1", "Wollemi Ridge Power Station", "NSW1", "Black Coal", "Steam Turbine", "Scheduled", "Generator", 720, None, 280, 42.0, 0.92, "Owned", 1982, -33.36, 150.05),
        ("WOLRG2", "Wollemi Ridge Power Station", "NSW1", "Black Coal", "Steam Turbine", "Scheduled", "Generator", 720, None, 280, 42.0, 0.92, "Owned", 1983, -33.36, 150.05),
        ("WOLRG3", "Wollemi Ridge Power Station", "NSW1", "Black Coal", "Steam Turbine", "Scheduled", "Generator", 720, None, 280, 43.0, 0.93, "Owned", 1984, -33.36, 150.05),
        ("WOLRG4", "Wollemi Ridge Power Station", "NSW1", "Black Coal", "Steam Turbine", "Scheduled", "Generator", 720, None, 280, 43.0, 0.93, "Owned", 1984, -33.36, 150.05),
        ("WOLBS1", "Wollemi Ridge Battery", "NSW1", "Battery Storage", "Battery Energy Storage System", "Scheduled", "Bidirectional unit", 460, 1840, 0, 0.0, 0.0, "Owned", 2025, -33.37, 150.07),
        ("BNDPH1", "Bundanoon Pumped Hydro", "NSW1", "Hydro", "Pumped Storage Hydro", "Scheduled", "Bidirectional unit", 240, 1800, 0, 0.0, 0.0, "Owned", 1977, -34.66, 150.30),
        ("RVNPK1", "Riverina Peaking Station", "NSW1", "Natural Gas", "Open Cycle Gas Turbine", "Scheduled", "Generator", 640, None, 60, 195.0, 0.62, "Owned", 2009, -35.20, 147.30),
        ("CNDVL1", "Condamine Valley Power Station", "QLD1", "Natural Gas", "Combined Cycle Gas Turbine", "Scheduled", "Generator", 630, None, 250, 92.0, 0.39, "Owned", 2010, -26.98, 150.60),
        ("CRGPK1", "Corangamite Peaking Station", "VIC1", "Natural Gas", "Open Cycle Gas Turbine", "Scheduled", "Generator", 275, None, 40, 175.0, 0.60, "Owned", 2011, -38.25, 142.90),
        ("CRGPK2", "Corangamite Peaking Station", "VIC1", "Natural Gas", "Open Cycle Gas Turbine", "Scheduled", "Generator", 275, None, 40, 178.0, 0.60, "Owned", 2011, -38.25, 142.90),
        ("GSVPK1", "Gulf St Vincent Peaking Station", "SA1", "Natural Gas", "Open Cycle Gas Turbine", "Scheduled", "Generator", 120, None, 20, 210.0, 0.65, "Owned", 2002, -34.80, 138.50),
        ("STRWF1", "Stony Rises Wind Farm", "VIC1", "Wind", "Wind Turbine", "Semi-scheduled", "Generator", 530, None, 0, 0.0, 0.0, "Contracted (PPA)", 2021, -38.40, 143.65),
        ("MNWWF1", "Mid North Wind Farm", "SA1", "Wind", "Wind Turbine", "Semi-scheduled", "Generator", 210, None, 0, 0.0, 0.0, "Contracted (PPA)", 2019, -33.60, 138.70),
        ("DPLSF1", "Darling Plains Solar Farm", "QLD1", "Solar", "Single-axis Tracking Solar PV", "Semi-scheduled", "Generator", 275, None, 0, 0.0, 0.0, "Contracted (PPA)", 2022, -27.60, 151.20),
    ],
    columns=[
        "duid", "station_name", "region_id", "fuel_type", "technology_type", "classification", "dispatch_type",
        "registered_capacity_mw", "storage_capacity_mwh", "min_stable_generation_mw", "srmc_aud_mwh",
        "emissions_intensity_t_mwh", "ownership_type", "commissioning_year", "latitude", "longitude",
    ],
)

BOOKS = pd.DataFrame(
    [
        ("BK101", "NSW Retail Load Hedge", "Retail Hedging", "Wholesale Hedging", "Buy hedges that cover NSW retail customer load", "Priya Raman", "NSW"),
        ("BK102", "QLD Retail Load Hedge", "Retail Hedging", "Wholesale Hedging", "Buy hedges that cover QLD retail customer load", "Jack Nguyen", "QLD"),
        ("BK103", "VIC Retail Load Hedge", "Retail Hedging", "Wholesale Hedging", "Buy hedges that cover VIC retail customer load", "Mei Lin Chen", "VIC"),
        ("BK104", "SA Retail Load Hedge", "Retail Hedging", "Wholesale Hedging", "Buy hedges that cover SA retail customer load", "Liam Fitzgerald", "SA"),
        ("BK201", "NSW Coal Generation Hedge", "Thermal Generation", "Generation Hedging", "Sell forward the expected output of Wollemi Ridge", "Tom Whitfield", "NSW"),
        ("BK202", "QLD Gas Generation Hedge", "Thermal Generation", "Generation Hedging", "Sell forward peak output of Condamine Valley", "Aisha Karim", "QLD"),
        ("BK203", "Peaking Fleet Cap Sales", "Flexible Generation", "Generation Hedging", "Sell $300 caps backed by the gas peaking fleet", "Aisha Karim", "Multi-region"),
        ("BK301", "Renewable PPA Portfolio", "Renewables", "Renewables and Origination", "Long-term offtake from contracted wind and solar farms", "Grace Okafor", "Multi-region"),
        ("BK302", "Storage Optimisation", "Flexible Generation", "Renewables and Origination", "Sell caps backed by the battery and pumped hydro", "Sam Brooks", "NSW"),
        ("BK401", "ASX Futures Flex Book", "Portfolio Optimisation", "Trading and Optimisation", "Rebalance the overall position with exchange futures", "Ravi Patel", "Multi-region"),
    ],
    columns=["book_id", "book_name", "portfolio", "desk", "strategy", "book_owner", "region_focus"],
)
DESK_TRADERS = BOOKS.groupby("desk")["book_owner"].apply(lambda s: sorted(set(s))).to_dict()

COUNTERPARTIES = pd.DataFrame(
    [
        ("CP001", "ASX Clear (Futures)", "Clearing House", "NR", 500_000_000, "ASX Operating Rules", True, "Australia"),
        ("CP002", "Tasman Bank Commodities", "Bank", "AA-", 150_000_000, "ISDA", False, "Australia"),
        ("CP003", "Southern Meridian Bank", "Bank", "A+", 120_000_000, "ISDA", False, "Australia"),
        ("CP004", "Harbourside Capital Markets", "Bank", "A", 80_000_000, "ISDA", False, "United Kingdom"),
        ("CP005", "Pacific Rim Commodities Pte Ltd", "Trading House", "BBB+", 40_000_000, "ISDA", False, "Singapore"),
        ("CP006", "Antipodean Energy Trading", "Trading House", "BBB", 25_000_000, "AFMA", False, "Australia"),
        ("CP007", "Coral Sea Generation", "Generator", "BBB", 45_000_000, "AFMA", False, "Australia"),
        ("CP008", "Great Dividing Energy", "Gentailer", "BBB+", 60_000_000, "AFMA", False, "Australia"),
        ("CP009", "Murray Basin Power", "Generator", "BBB-", 20_000_000, "AFMA", False, "Australia"),
        ("CP010", "Bass Strait Hydro", "Generator", "A-", 70_000_000, "AFMA", False, "Australia"),
        ("CP011", "Ghost Gum Energy", "Gentailer", "BBB", 35_000_000, "AFMA", False, "Australia"),
        ("CP012", "Spinifex Power", "Generator", "BBB-", 12_000_000, "AFMA", False, "Australia"),
        ("CP013", "Harbour City Energy Retail", "Retailer", "BB+", 15_000_000, "AFMA", False, "Australia"),
        ("CP014", "Blue Wren Energy", "Retailer", "BBB-", 18_000_000, "AFMA", False, "Australia"),
        ("CP015", "Jacaranda Power and Gas", "Retailer", "BB", 10_000_000, "AFMA", False, "Australia"),
        ("CP016", "Kookaburra Energy", "Retailer", "BB+", 12_000_000, "AFMA", False, "Australia"),
        ("CP017", "Outback Aluminium", "Industrial", "BBB", 50_000_000, "ISDA", False, "Australia"),
        ("CP018", "Gulf Copper Smelting", "Industrial", "BBB-", 30_000_000, "ISDA", False, "Australia"),
        ("CP019", "Riverland Food Processing", "Industrial", "BBB", 15_000_000, "AFMA", False, "Australia"),
        ("CP020", "Ironbark Steel Mills", "Industrial", "BB+", 20_000_000, "AFMA", False, "Australia"),
        ("CP021", "Southern Metro Transit Authority", "Government", "AA", 80_000_000, "AFMA", False, "Australia"),
        ("CP022", "Windward Renewables", "Renewable Developer", "BBB", 40_000_000, "AFMA", False, "Australia"),
        ("CP023", "Sunbelt Solar Holdings", "Renewable Developer", "BBB-", 25_000_000, "AFMA", False, "Australia"),
        ("CP024", "Mid North Wind Pty Ltd", "Renewable Developer", "BBB", 30_000_000, "AFMA", False, "Australia"),
        ("CP025", "Gondwana Energy Partners", "Trading House", "BBB-", 15_000_000, "AFMA", False, "Australia"),
    ],
    columns=["counterparty_id", "counterparty_name", "counterparty_type", "credit_rating", "credit_limit_aud", "master_agreement", "is_exchange_cleared", "country"],
)
CP_BY_TYPE = COUNTERPARTIES.groupby("counterparty_type")["counterparty_id"].apply(list).to_dict()


def ar1(n, phi):
    """Stationary AR(1) series with unit variance (smooth random noise)."""
    eps = rng.normal(0.0, math.sqrt(1.0 - phi * phi), n)
    x0 = rng.normal()
    try:
        from scipy.signal import lfilter

        x = lfilter([1.0], [1.0, -phi], eps)
    except ImportError:
        x = np.empty(n)
        prev = 0.0
        for i in range(n):
            prev = phi * prev + eps[i]
            x[i] = prev
    return x + x0 * phi ** np.arange(n)


def bump(h, centre, width):
    return np.exp(-0.5 * ((h - centre) / width) ** 2)


def latest_window(month, day, length_days):
    """Most recent date range of the given length starting on month/day that sits fully inside the data window."""
    for year in range(END_DATE.year, END_DATE.year - 3, -1):
        start = date(year, month, day)
        end = start + timedelta(days=length_days - 1)
        if start >= START_DATE and end < END_DATE:
            return start, end
    return None


def quarter_start(d):
    return date(d.year, 3 * ((d.month - 1) // 3) + 1, 1)


def add_quarters(q, k):
    m = q.month - 1 + 3 * k
    return date(q.year + m // 12, m % 12 + 1, 1)


def quarter_end(q):
    return add_quarters(q, 1) - timedelta(days=1)


def quarter_label(q):
    return f"Q{(q.month - 1) // 3 + 1} {q.year}"


def quarters_between(a, b):
    return (b.year - a.year) * 4 + ((b.month - 1) // 3 - (a.month - 1) // 3)


def market_price_cap(d):
    fy = d.year + (1 if d.month >= 7 else 0)
    return MARKET_PRICE_CAP.get(fy, MARKET_PRICE_CAP[max(MARKET_PRICE_CAP)] if fy > max(MARKET_PRICE_CAP) else MARKET_PRICE_CAP[min(MARKET_PRICE_CAP)])


def profile_hours(start, end, profile):
    """Hours in a delivery period for a profile (Peak = 07:00 to 22:00 on weekdays)."""
    if profile == "Peak":
        return 15.0 * len(pd.bdate_range(start, end))
    return 24.0 * ((end - start).days + 1)


# Storylines participants can discover in the dashboards and Genie
HEATWAVE = latest_window(1, 20, 4)  # South Australia and Victoria heatwave with prices at the market price cap
WINTER_SQUEEZE = latest_window(6, 9, 12)  # cold, still winter fortnight: low wind and high NSW and QLD evening prices
UNIT3_OUTAGE = latest_window(6, 6, 18)  # forced outage of Wollemi Ridge unit 3 during the winter squeeze
UNIT2_PLANNED = latest_window(3, 16, 28)  # planned autumn maintenance on Wollemi Ridge unit 2

print(f"Data window: {START_DATE} to {END_DATE - timedelta(days=1)} (market time). Valuations as of {AS_OF_DATE}.")
print(f"Storylines: heatwave {HEATWAVE}, winter squeeze {WINTER_SQUEEZE}, unit 3 outage {UNIT3_OUTAGE}")

# COMMAND ----------

# Step 4: AEMO-style market data. 5-minute demand, renewables and spot prices for each region.
ts_end = pd.date_range(pd.Timestamp(START_DATE) + pd.Timedelta(minutes=5), pd.Timestamp(END_DATE), freq="5min")
N = len(ts_end)
ts_start = ts_end - pd.Timedelta(minutes=5)
hour = (ts_start.hour + ts_start.minute / 60.0 + 2.5 / 60.0).to_numpy()
day_index = (ts_start.normalize() - pd.Timestamp(START_DATE)).days.to_numpy()
all_days = pd.date_range(START_DATE, periods=HISTORY_DAYS, freq="D")
doy = all_days.dayofyear.to_numpy()[day_index]
weekend = all_days.dayofweek.to_numpy()[day_index] >= 5
is_peak = (~weekend) & (ts_start.hour.to_numpy() >= 7) & (ts_start.hour.to_numpy() < 22)
interval_dates = np.array(ts_start.normalize().date)
season_angle = 2 * np.pi * (doy - 20) / 365.25
summer = np.clip(np.cos(season_angle), 0, None)
winter = np.clip(-np.cos(season_angle), 0, None)
cap_by_interval = np.array([market_price_cap(d.date()) for d in all_days])[day_index]


def window_mask(window, pad_days=0):
    if window is None:
        return np.zeros(N, dtype=bool)
    s, e = window
    return (day_index >= (s - START_DATE).days - pad_days) & (day_index <= (e - START_DATE).days + pad_days)


def window_ramp(window, ramp_days=2.0):
    """0 to 1 weight that ramps in and out around a storyline window (in fractional days)."""
    if window is None:
        return np.zeros(N)
    s, e = window
    t = day_index + hour / 24.0
    a, b = (s - START_DATE).days, (e - START_DATE).days + 1
    return np.clip(np.minimum((t - a + ramp_days) / ramp_days, (b + ramp_days - t) / ramp_days), 0, 1)


heat_mask, squeeze_mask = window_mask(HEATWAVE), window_mask(WINTER_SQUEEZE)
squeeze_ramp = window_ramp(WINTER_SQUEEZE)
heat_ramp = window_ramp(HEATWAVE, 0.5)

phi_wind = math.exp(-1.0 / (288 * 1.2))
wind_south, wind_north = ar1(N, phi_wind), ar1(N, phi_wind)
fuel_common = ar1(HISTORY_DAYS, 0.93)
weather_common = ar1(HISTORY_DAYS, 0.7)
cloud_common = rng.normal(size=HISTORY_DAYS)

market = {}
for region_id, p in REGION_MODEL.items():
    south = region_id in ("VIC1", "SA1", "TAS1")
    # Wind: multi-day weather regimes shared with neighbouring regions, windier in winter and at night in the south
    own = ar1(N, phi_wind)
    slow = (0.75 * wind_south + 0.66 * own) if south else (0.60 * wind_north + 0.30 * wind_south + 0.74 * own)
    slow = slow / slow.std()
    wind_cf = 0.31 + (0.06 if south else 0.03) * np.cos(2 * np.pi * (doy - 255) / 365.25) + 0.20 * slow + 0.04 * ar1(N, 0.95)
    if south:
        wind_cf += 0.03 * np.cos(2 * np.pi * (hour - 3) / 24)
    if region_id in ("NSW1", "QLD1", "VIC1"):
        wind_cf -= 0.24 * squeeze_ramp
    if region_id in ("SA1", "VIC1"):
        wind_cf -= 0.20 * heat_ramp
    wind_mw = p["wind"] * np.clip(wind_cf, 0.01, 0.96)

    # Solar: day length and strength follow the season; daily cloud cover is shared across regions
    daylen = 12 + p["daylen"] * np.cos(2 * np.pi * (doy - 355) / 365.25)
    xs = (hour - (p["noon"] - daylen / 2)) / daylen
    sun = np.where((xs > 0) & (xs < 1), np.sin(np.pi * np.clip(xs, 0, 1)) ** 1.4, 0.0)
    intensity = 0.80 + 0.20 * np.cos(2 * np.pi * (doy - 355) / 365.25)
    cloud_daily = np.clip(0.83 + 0.14 * (0.6 * cloud_common + 0.8 * rng.normal(size=HISTORY_DAYS)) - (0.05 if south else 0.0) * np.clip(-np.cos(2 * np.pi * (all_days.dayofyear.to_numpy() - 20) / 365.25), 0, None), 0.3, 1.0)
    solar_shape = sun * intensity * cloud_daily[day_index] * np.clip(1 + 0.05 * ar1(N, 0.9), 0.8, 1.1)
    tracking = np.where((xs > 0) & (xs < 1), np.sin(np.pi * np.clip(xs, 0, 1)) ** 0.75, 0.0)  # single-axis trackers
    rooftop_mw = p["rooftop"] * 0.62 * solar_shape
    utility_solar_mw = p["solar"] * 0.85 * tracking * intensity * cloud_daily[day_index]

    # Underlying demand: morning and evening peaks, heat-driven summer afternoons, heating-driven winter evenings
    shape = 0.80 + 0.16 * bump(hour, 8.0, 1.6) + 0.17 * bump(hour, 13.0, 3.2) + 0.30 * bump(hour, 18.8, 1.8) - 0.06 * bump(hour, 3.5, 1.5)
    shape = np.where(weekend, 0.93 * shape - 0.06 * bump(hour, 8.0, 1.6), shape)
    shape = shape + summer * p["summer"] * (1.6 * bump(hour, 16.5, 2.8) + 1.0 * bump(hour, 13.5, 3.0)) + winter * p["winter"] * (1.2 * bump(hour, 18.3, 1.6) + 0.6 * bump(hour, 7.8, 1.3))
    weather = 1 + 0.03 * (0.6 * weather_common + 0.8 * ar1(HISTORY_DAYS, 0.7))[day_index]
    underlying = p["demand"] * shape * (1 + 0.5 * p["summer"] * summer + 0.5 * p["winter"] * winter) * weather * (1 + 0.012 * ar1(N, 0.97))
    heat_boost = {"SA1": 0.17, "VIC1": 0.15, "NSW1": 0.08}.get(region_id, 0.0)
    underlying *= 1 + heat_boost * heat_ramp * (0.4 + bump(hour, 16.5, 3.0))
    underlying *= 1 + 0.05 * squeeze_ramp * bump(hour, 18.5, 2.0)
    total_demand = np.maximum(underlying - rooftop_mw, 0.12 * p["demand"])

    # Spot price: driven by residual demand (demand left after wind and solar), fuel costs and scarcity
    residual = total_demand - wind_mw - utility_solar_mw
    x = residual / total_demand.mean()
    z = (x - np.median(x)) / x.std()
    day_factor = np.exp(0.10 * fuel_common + 0.06 * ar1(HISTORY_DAYS, 0.9))[day_index] * (1 + 0.08 * winter)
    day_factor *= 1 + {"NSW1": 0.55, "QLD1": 0.30, "VIC1": 0.20, "SA1": 0.20}.get(region_id, 0.05) * squeeze_ramp
    negative = 62.0 / (1 + np.exp(-(p["neg_z"] - z) / 0.25))
    price = p["price"] * day_factor * np.exp(p["kappa"] * z) * np.exp(0.07 * ar1(N, 0.9)) - negative + rng.normal(0, 2.0, N)
    deep = (price < -20) & (rng.random(N) < 0.004)  # occasional bidding to the floor when generators must stay on
    price[deep] = -rng.uniform(150, 1000, deep.sum())

    # Scarcity spikes: more likely when residual demand is very high, and in evening peaks
    evening = (hour >= 16) & (hour < 21)
    spike_prob = (np.clip(0.02 * (z - 2.4), 0, 0.15) + 0.0005 * evening) * (0.25 if region_id == "TAS1" else 1.0)
    if region_id == "NSW1":
        spike_prob += 0.16 * squeeze_mask * ((hour >= 17) & (hour < 20.5))
    if region_id == "QLD1":
        spike_prob += 0.05 * squeeze_mask * ((hour >= 17) & (hour < 20))
    starts = np.flatnonzero(rng.random(N) < spike_prob)
    for i in starts:
        duration = min(rng.geometric(0.45), 6)
        level = CAP_STRIKE + math.exp(rng.normal(6.3 if not squeeze_mask[i] else 5.9, 0.95))
        for j in range(duration):
            if i + j < N:
                price[i + j] = max(price[i + j], level * (0.85 ** j))

    # Heatwave: the worst two afternoons push South Australia and Victoria to the market price cap
    if HEATWAVE is not None and region_id in ("SA1", "VIC1", "NSW1"):
        for k in (1, 2, 3):
            day0 = (HEATWAVE[0] - START_DATE).days + k
            window = np.flatnonzero((day_index == day0) & (hour >= 15.5) & (hour < 19.75))
            n_hot = {"SA1": 20, "VIC1": 14, "NSW1": 6 if k == 2 else 0}[region_id]
            n_cap = {"SA1": 9, "VIC1": 6, "NSW1": 1 if k == 2 else 0}[region_id]
            hot = rng.choice(window, size=n_hot, replace=False) if n_hot else np.array([], dtype=int)
            price[hot] = rng.uniform(2500, 14000, size=len(hot))
            price[hot[:n_cap]] = cap_by_interval[hot[:n_cap]]

    market[region_id] = dict(
        price=price, total_demand=total_demand, rooftop=rooftop_mw, wind=wind_mw, utility_solar=utility_solar_mw,
        underlying=underlying, z=z,
    )

# Tasmania follows Victoria across Basslink, so blend the two
vic_link = np.clip(market["VIC1"]["price"], -60, 350)
market["TAS1"]["price"] = 0.55 * market["TAS1"]["price"] + 0.45 * vic_link
for region_id in market:
    market[region_id]["price"] = np.clip(market[region_id]["price"], MARKET_FLOOR, cap_by_interval)

# Interconnector flows (positive = exporting) and available generation
noise = {r: ar1(N, 0.98) for r in REGION_MODEL}
qld = market["QLD1"]
nx = {}
nx["QLD1"] = np.clip(700 + 0.25 * (qld["utility_solar"] - qld["utility_solar"].mean()) - 0.15 * (qld["total_demand"] - qld["total_demand"].mean()) + 120 * noise["QLD1"], -1200, 1800)
sa = market["SA1"]
nx["SA1"] = np.clip(0.55 * (sa["wind"] + sa["utility_solar"] - 0.45 * sa["total_demand"]) + 60 * noise["SA1"], -750, 750)
nx["TAS1"] = np.clip(250 * np.cos(2 * np.pi * (hour - 19) / 24) - 100 + 80 * noise["TAS1"], -480, 480)
vic = market["VIC1"]
vic_ren = vic["wind"] + vic["utility_solar"]
nx["VIC1"] = np.clip(0.35 * (vic_ren - vic_ren.mean()) + 300 - 0.8 * nx["SA1"] - 0.9 * nx["TAS1"] + 150 * noise["VIC1"], -1800, 2400)
nx["NSW1"] = -0.97 * (nx["QLD1"] + nx["SA1"] + nx["TAS1"] + nx["VIC1"])

unit3_out = window_mask(UNIT3_OUTAGE)
dispatch_frames = []
for region_id, p in REGION_MODEL.items():
    m = market[region_id]
    thermal = p["thermal"] * (1 + 0.03 * ar1(HISTORY_DAYS, 0.8))[day_index]
    if region_id == "NSW1":
        thermal -= 720 * unit3_out
    if region_id in ("SA1", "VIC1"):
        thermal *= 1 - 0.08 * heat_mask
    available = thermal + m["wind"] + m["utility_solar"]
    dispatch_frames.append(
        pd.DataFrame(
            {
                "settlement_date": ts_end,
                "trading_date": interval_dates,
                "hour_of_day": ts_start.hour.astype("int32"),
                "is_peak_period": is_peak,
                "region_id": region_id,
                "rrp_aud_mwh": np.round(m["price"], 2),
                "total_demand_mw": np.round(m["total_demand"], 2),
                "rooftop_solar_mw": np.round(m["rooftop"], 2),
                "wind_generation_mw": np.round(m["wind"], 2),
                "utility_solar_mw": np.round(m["utility_solar"], 2),
                "available_generation_mw": np.round(available, 2),
                "net_interchange_mw": np.round(nx[region_id], 2),
            }
        )
    )
dispatch_region = pd.concat(dispatch_frames, ignore_index=True)
print(f"aemo_dispatch_region: {len(dispatch_region):,} rows")

# COMMAND ----------

# Step 5: AEMO-style unit output. Each unit responds to its regional price the way that technology does.
def ramp_limited(target, up, down):
    out = np.empty_like(target)
    prev = target[0]
    for i in range(len(target)):
        t = target[i]
        prev = min(t, prev + up) if t >= prev else max(t, prev - down)
        out[i] = prev
    return out


def outage_mask(duid):
    mask = np.zeros(N, dtype=bool)
    if duid == "WOLRG3":
        mask |= unit3_out
    if duid == "WOLRG2":
        mask |= window_mask(UNIT2_PLANNED)
    for _ in range(2):  # a couple of short unplanned trips per unit per year
        d0 = int(rng.integers(0, HISTORY_DAYS - 3))
        mask |= (day_index >= d0) & (day_index < d0 + int(rng.integers(1, 4)))
    return mask


daily_rank_cache = {}


def daily_price_rank(region_id):
    """Rank of each interval's price within its day (0 = cheapest)."""
    if region_id not in daily_rank_cache:
        s = pd.Series(market[region_id]["price"])
        daily_rank_cache[region_id] = s.groupby(day_index).rank(method="first").to_numpy() - 1
    return daily_rank_cache[region_id]


unit_frames = []
for u in GENERATING_UNITS.itertuples():
    price = market[u.region_id]["price"]
    cap = float(u.registered_capacity_mw)
    if u.fuel_type == "Black Coal":
        out = outage_mask(u.duid)
        derate = np.where(rng.random(HISTORY_DAYS) < 0.06, 0.86, 1.0)[day_index]
        available = np.where(out, 0.0, cap * derate)
        frac = np.clip((price - 20.0) / 120.0, 0, 1)
        target = np.where(out, 0.0, u.min_stable_generation_mw + (available - u.min_stable_generation_mw) * frac)
        scada = ramp_limited(target, 35.0, 35.0)
        scada = np.where(out, 0.0, np.clip(scada + rng.normal(0, 4, N), 0, None))
    elif u.technology_type == "Combined Cycle Gas Turbine":
        out = outage_mask(u.duid)
        available = np.where(out, 0.0, cap)
        committed = pd.Series(price).rolling(24, min_periods=1).mean().to_numpy() > 45
        level = u.min_stable_generation_mw + (cap - u.min_stable_generation_mw) * np.clip((price - u.srmc_aud_mwh) / 60.0, 0, 1)
        target = np.where(out | ~committed, 0.0, level)
        scada = np.clip(ramp_limited(target, 30.0, 40.0) + rng.normal(0, 3, N) * (target > 0), 0, None)
    elif u.technology_type == "Open Cycle Gas Turbine":
        out = outage_mask(u.duid)
        available = np.where(out, 0.0, cap)
        target = np.where(out, 0.0, cap * np.clip((price - u.srmc_aud_mwh) / (0.3 * u.srmc_aud_mwh), 0, 1))
        scada = ramp_limited(target, cap / 2, cap / 2)
    elif u.fuel_type == "Battery Storage":
        # one cycle a day: charge in the cheapest intervals, discharge in the dearest, with 88% round-trip efficiency
        rank = daily_price_rank(u.region_id)
        available = np.full(N, cap)
        charge = np.where(rank < 40, -cap, np.where(rank < 70, -0.55 * cap, 0.0))
        discharge = 0.88 * np.where(rank >= 258, cap, np.where(rank >= 228, 0.55 * cap, 0.0))
        spread = pd.Series(price).groupby(day_index).transform(lambda s: s.nlargest(60).mean() - s.nsmallest(70).mean()).to_numpy()
        scada = np.where(spread > 40, charge + discharge, 0.0)
    elif u.technology_type == "Pumped Storage Hydro":
        rank = daily_price_rank(u.region_id)
        available = np.full(N, cap)
        scada = np.zeros(N)
        level, store = 900.0, float(u.storage_capacity_mwh)
        for i in range(N):
            if rank[i] >= 252 and price[i] > 150 and level > 20:
                scada[i] = cap
                level -= cap / 12
            elif rank[i] < 48 and price[i] < 40 and level < store - 20:
                scada[i] = -cap
                level += 0.76 * cap / 12
    elif u.fuel_type == "Wind":
        cf = market[u.region_id]["wind"] / REGION_MODEL[u.region_id]["wind"]
        available = cap * np.clip(cf * (1 + 0.12 * ar1(N, 0.99)), 0, 1)
        scada = np.where(price < -40, 0.0, np.where(price < -10, 0.5 * available, available))
    else:  # utility solar
        shape = market[u.region_id]["utility_solar"] / (REGION_MODEL[u.region_id]["solar"] * 0.85 * 0.98)
        available = cap * 0.98 * np.clip(shape * (1 + 0.04 * ar1(N, 0.9)), 0, 1)
        scada = np.where(price < -35, 0.3 * available, np.where(price < -20, 0.7 * available, available))
    scada = np.round(scada, 2)
    unit_frames.append(
        pd.DataFrame(
            {
                "settlement_date": ts_end,
                "trading_date": interval_dates,
                "duid": u.duid,
                "scada_mw": scada,
                "available_mw": np.round(available, 2),
                "energy_mwh": np.round(scada / 12.0, 4),
            }
        )
    )
unit_dispatch = pd.concat(unit_frames, ignore_index=True)
print(f"aemo_unit_dispatch: {len(unit_dispatch):,} rows")

# COMMAND ----------

# Step 6: ETRM forward curves. Daily end-of-day quarterly prices for Base, Peak and $300 Cap in each futures region.
CURVE_REGIONS = list(REGIONS.loc[REGIONS.has_exchange_futures, "region_id"])
CURVE_START = START_DATE - timedelta(days=200)
TRADE_START = START_DATE - timedelta(days=180)
curve_days = [d.date() for d in pd.bdate_range(CURVE_START, AS_OF_DATE)]
first_q = quarter_start(CURVE_START)
quarters = [add_quarters(first_q, k) for k in range(quarters_between(first_q, quarter_start(AS_OF_DATE)) + 12)]
nq, nd = len(quarters), len(curve_days)

# Realised spot statistics by region and quarter-of-year anchor the curve levels
spot = pd.DataFrame({"day": day_index, "qoy": (all_days.quarter.to_numpy()[day_index]), "peak": is_peak})
daily_realised = {}
qoy_level = {}
for r in CURVE_REGIONS:
    pr = market[r]["price"]
    spot["p"] = pr
    spot["cap_payout"] = np.maximum(pr - CAP_STRIKE, 0)
    spot["p_peak"] = np.where(is_peak, pr, 0.0)
    g = spot.groupby("qoy")
    base_q = g["p"].mean()
    peak_q = spot[spot.peak].groupby("qoy")["p"].mean()
    cap_q = g["cap_payout"].mean()
    overall = (float(pr.mean()), float(pr[is_peak].mean() / pr.mean()), float(np.maximum(pr - CAP_STRIKE, 0).mean()))
    qoy_level[r] = {q: (base_q[q], peak_q[q] / base_q[q], cap_q[q]) for q in base_q.index}
    for q in (1, 2, 3, 4):
        qoy_level[r].setdefault(q, overall)  # short history windows may not cover every quarter
    d = spot.groupby("day").agg(p_sum=("p", "sum"), n=("p", "size"), peak_sum=("p_peak", "sum"), peak_n=("peak", "sum"), cap_sum=("cap_payout", "sum"))
    daily_realised[r] = d.cumsum()  # cumulative sums by day for quarter-to-date averages


BASE_SEASON = {1: 1.08, 2: 0.98, 3: 1.12, 4: 0.82}  # summer and winter quarters trade at a premium, spring is cheapest
CAP_SEASON = {1: 1.45, 2: 0.75, 3: 1.25, 4: 0.55}
annual_level = {r: (float(market[r]["price"].mean()), float(np.maximum(market[r]["price"] - CAP_STRIKE, 0).mean()) * 1.25 + 4.0) for r in CURVE_REGIONS}


def realised_to_date(r, q_start, d):
    """Quarter-to-date realised base, peak and cap payout averages from the spot data, or None if not covered."""
    if q_start < START_DATE or d < q_start:
        return None
    cum = daily_realised[r]
    i1 = min((d - START_DATE).days, len(cum) - 1)
    i0 = (q_start - START_DATE).days - 1
    row1 = cum.iloc[i1]
    row0 = cum.iloc[i0] if i0 >= 0 else pd.Series(0.0, index=cum.columns)
    dv = row1 - row0
    if dv["n"] == 0:
        return None
    return dv["p_sum"] / dv["n"], (dv["peak_sum"] / dv["peak_n"]) if dv["peak_n"] > 0 else None, dv["cap_sum"] / dv["n"]


def storyline_bump(r, q, d):
    """Forward market reaction to the storylines: the winter squeeze lifts winter quarters, the heatwave lifts summer caps."""
    base_mult, cap_mult = 1.0, 1.0
    if WINTER_SQUEEZE is not None:
        s, e = WINTER_SQUEEZE
        size = {"NSW1": 0.35, "QLD1": 0.25, "VIC1": 0.15, "SA1": 0.15}[r]
        lead = (d - (s - timedelta(days=20))).days
        if lead >= 0:
            weight = min(lead / 20.0, 1.0)
            after = (d - e).days - 10
            if after > 0:
                weight = 0.4 + 0.6 * math.exp(-after / 30.0)
            if q == quarter_start(s + timedelta(days=30)):
                base_mult *= 1 + size * weight
            elif q > s:
                # a smaller, lasting risk premium on later quarters, largest on the next winter
                persist = 0.12 if (q.month == 7) else 0.05
                base_mult *= 1 + size / 0.35 * persist * min(lead / 20.0, 1.0)
    if HEATWAVE is not None and r in ("SA1", "VIC1"):
        s, _ = HEATWAVE
        if d >= s:
            if q == quarter_start(s):
                cap_mult *= 1.8
            elif q.month == 1:
                cap_mult *= 1.15
    return base_mult, cap_mult


eps_common = rng.normal(size=nd)
curve_rows = []
for ri, r in enumerate(CURVE_REGIONS):
    eps_region = rng.normal(size=nd)
    eps_quarter = rng.normal(size=(nq, nd))
    dev = np.zeros(nq)
    for t, d in enumerate(curve_days):
        dq = quarter_start(d)
        ahead = np.array([quarters_between(dq, q) for q in quarters])
        sigma = 0.011 + 0.011 * np.exp(-0.35 * np.clip(ahead, 0, None))
        dev = 0.985 * dev + sigma * (0.65 * eps_common[t] + 0.55 * eps_region[t] + 0.5 * eps_quarter[:, t])
        for qi, q in enumerate(quarters):
            if ahead[qi] < 0 or ahead[qi] > 11:
                continue
            qoy = (q.month - 1) // 3 + 1
            _, peak_ratio, _ = qoy_level[r][qoy]
            base_level = annual_level[r][0] * BASE_SEASON[qoy]
            cap_level = annual_level[r][1] * CAP_SEASON[qoy]
            years_out = max((q - END_DATE).days / 365.25, 0.0)
            trend = 0.975 ** years_out
            b_mult, c_mult = storyline_bump(r, q, d)
            base = base_level * 1.04 * trend * math.exp(dev[qi]) * b_mult
            peak = base * peak_ratio * math.exp(0.3 * dev[qi] * 0.2)
            cap = cap_level * math.exp(1.6 * dev[qi]) * c_mult
            if ahead[qi] == 0:
                realised = realised_to_date(r, q, d)
                if realised is not None:
                    w = ((d - q).days + 1) / ((quarter_end(q) - q).days + 1)
                    base = w * realised[0] + (1 - w) * base
                    if realised[1] is not None:
                        peak = w * realised[1] + (1 - w) * peak
                    cap = w * realised[2] + (1 - w) * cap
            source = "Exchange settlement" if ahead[qi] <= 7 else "Broker composite"
            for profile, value in (("Base", base), ("Peak", peak), ("Cap $300", cap)):
                curve_rows.append((d, f"{STATE[r]} {profile} Quarterly", r, profile, quarter_label(q), q, quarter_end(q), round(float(value), 2), source))

forward_curve = pd.DataFrame(
    curve_rows,
    columns=["curve_date", "curve_name", "region_id", "profile", "contract_period", "period_start", "period_end", "price_aud_mwh", "price_source"],
)
curve_lookup = dict(zip(zip(forward_curve.curve_date, forward_curve.region_id, forward_curve.profile, forward_curve.contract_period), forward_curve.price_aud_mwh))
print(f"etrm_forward_curve: {len(forward_curve):,} rows")

# COMMAND ----------

# Step 7: ETRM trades. Hedging books buy or sell swaps, caps and futures; the PPA book holds three long-term offtakes.
FIRST_DELIVERY_Q = add_quarters(quarter_start(START_DATE), 1) if quarter_start(START_DATE) < START_DATE else quarter_start(START_DATE)
LAST_DELIVERY_Q = add_quarters(quarter_start(AS_OF_DATE), 8)
trade_days = [d.date() for d in pd.bdate_range(TRADE_START, AS_OF_DATE)]

BOOK_MIX = {
    # book: (number of trades, regions, [(instrument, profile, buy/sell, weight)])
    "BK101": (240, ["NSW1"], [("Swap", "Base", "Buy", 0.42), ("Swap", "Peak", "Buy", 0.18), ("Cap", "Cap $300", "Buy", 0.25), ("Future", "Base", "Buy", 0.10), ("Future", "Base", "Sell", 0.05)]),
    "BK102": (190, ["QLD1"], [("Swap", "Base", "Buy", 0.45), ("Swap", "Peak", "Buy", 0.20), ("Cap", "Cap $300", "Buy", 0.25), ("Future", "Base", "Buy", 0.10)]),
    "BK103": (190, ["VIC1"], [("Swap", "Base", "Buy", 0.45), ("Swap", "Peak", "Buy", 0.15), ("Cap", "Cap $300", "Buy", 0.30), ("Future", "Base", "Buy", 0.10)]),
    "BK104": (120, ["SA1"], [("Swap", "Base", "Buy", 0.40), ("Cap", "Cap $300", "Buy", 0.45), ("Future", "Base", "Buy", 0.15)]),
    "BK201": (180, ["NSW1"], [("Swap", "Base", "Sell", 0.60), ("Future", "Base", "Sell", 0.30), ("Swap", "Peak", "Sell", 0.10)]),
    "BK202": (100, ["QLD1"], [("Swap", "Peak", "Sell", 0.60), ("Future", "Peak", "Sell", 0.40)]),
    "BK203": (150, ["NSW1", "VIC1", "SA1"], [("Cap", "Cap $300", "Sell", 0.85), ("Future", "Cap $300", "Sell", 0.15)]),
    "BK302": (60, ["NSW1"], [("Cap", "Cap $300", "Sell", 1.0)]),
    "BK401": (230, CURVE_REGIONS, [("Future", "Base", "Buy", 0.30), ("Future", "Base", "Sell", 0.30), ("Future", "Peak", "Buy", 0.15), ("Future", "Peak", "Sell", 0.15), ("Future", "Cap $300", "Buy", 0.05), ("Future", "Cap $300", "Sell", 0.05)]),
}
OTC_COUNTERPARTY_TYPES = {
    "Buy": (["Generator", "Gentailer", "Bank", "Trading House"], [0.30, 0.25, 0.30, 0.15]),
    "Sell": (["Retailer", "Industrial", "Bank", "Government", "Trading House"], [0.30, 0.30, 0.22, 0.08, 0.10]),
}
BROKERS = ["Coastline Energy Brokers", "Harbour Street Brokers", "Southern Cross Broking"]


def pick_counterparty(direction, instrument):
    if instrument == "Future":
        return "CP001"
    types, weights = OTC_COUNTERPARTY_TYPES[direction]
    cp_type = rng.choice(types, p=weights)
    choices = [c for c in CP_BY_TYPE[cp_type] if c != "CP012"]
    return rng.choice(choices)


def pick_trader(book_id):
    owner, desk = BOOKS.set_index("book_id").loc[book_id, ["book_owner", "desk"]]
    peers = DESK_TRADERS[desk]
    return owner if (rng.random() < 0.8 or len(peers) == 1) else rng.choice(peers)


def volume_for(instrument, book_id):
    if instrument == "Future":
        return float(rng.choice([1, 2, 3, 5, 5, 10, 10, 15, 20, 25]))
    if book_id == "BK302":
        return float(rng.choice([10, 20, 25, 30, 40, 50]))
    return float(rng.choice([5, 10, 10, 15, 20, 20, 25, 30, 40, 50]))


def make_trade(book_id, region_id, instrument, profile, direction, trade_day, delivery_q, counterparty_id=None, volume=None):
    price = float(curve_lookup[(trade_day, region_id, profile, quarter_label(delivery_q))])
    price *= 1 + rng.normal(0, 0.012) + (0.004 if direction == "Buy" else -0.004)
    price = round(round(price / 0.05) * 0.05, 2)
    start, end = delivery_q, quarter_end(delivery_q)
    volume = volume or volume_for(instrument, book_id)
    mwh = volume * profile_hours(start, end, "Peak" if profile == "Peak" else "Base")
    venue = "ASX24" if instrument == "Future" else rng.choice(["OTC broker", "OTC bilateral"], p=[0.65, 0.35])
    return dict(
        trade_date=trade_day, book_id=book_id, trader_name=pick_trader(book_id),
        counterparty_id=counterparty_id or pick_counterparty(direction, instrument), instrument_type=instrument,
        profile=profile, buy_sell=direction, region_id=region_id, delivery_period=quarter_label(delivery_q),
        delivery_start=start, delivery_end=end, volume_mw=volume, contract_mwh=round(mwh, 2), price_aud_mwh=price,
        strike_price_aud_mwh=CAP_STRIKE if profile == "Cap $300" else None, linked_duid=None, execution_venue=venue,
        broker_name=rng.choice(BROKERS) if venue == "OTC broker" else None,
    )


trades = []
for book_id, (n_trades, regions, mix) in BOOK_MIX.items():
    weights = np.array([m[3] for m in mix])
    for _ in range(n_trades):
        instrument, profile, direction, _w = mix[rng.choice(len(mix), p=weights / weights.sum())]
        region_id = rng.choice(regions, p=[0.40, 0.30, 0.30] if book_id == "BK203" else None)
        trade_day = trade_days[int(rng.integers(0, len(trade_days)))]
        options = [q for q in quarters if q > trade_day and FIRST_DELIVERY_Q <= q <= LAST_DELIVERY_Q and quarters_between(quarter_start(trade_day), q) <= 8]
        ahead = np.array([quarters_between(quarter_start(trade_day), q) for q in options], dtype=float)
        prob = np.exp(-0.22 * ahead)
        if profile == "Cap $300":
            prob = prob * np.array([{1: 2.0, 2: 0.7, 3: 1.5, 4: 0.6}[(q.month - 1) // 3 + 1] for q in options])
        delivery_q = options[rng.choice(len(options), p=prob / prob.sum())]
        trades.append(make_trade(book_id, region_id, instrument, profile, direction, trade_day, delivery_q))

# Storyline: before the winter squeeze, NSW Retail bought a block of base swaps from Spinifex Power, a small generator
if WINTER_SQUEEZE is not None:
    squeeze_start = WINTER_SQUEEZE[0]
    next_winter = date(squeeze_start.year + 1, 7, 1)
    next_summer = date(squeeze_start.year + 1, 1, 1)
    window_days = [d for d in trade_days if squeeze_start - timedelta(days=150) <= d <= squeeze_start - timedelta(days=30)]
    for i in range(22):
        q = next_winter if i % 3 else next_summer
        trades.append(make_trade("BK101", "NSW1", "Swap", "Base", "Buy", window_days[int(rng.integers(0, len(window_days)))], q, "CP012", float(rng.choice([20, 25, 30, 35]))))

trades = pd.DataFrame(trades).sort_values(["trade_date", "book_id"]).reset_index(drop=True)
trades.insert(0, "trade_id", [f"DL{104000 + i}" for i in range(len(trades))])

# Realised capture prices let the three PPAs carry sensible fixed prices
unit_energy = {d: unit_dispatch.loc[unit_dispatch.duid == d, "scada_mw"].to_numpy() for d in ("STRWF1", "MNWWF1", "DPLSF1")}
PPA_SPEC = [
    ("STRWF1", "VIC1", "CP022", date(2022, 1, 1), date(2034, 12, 31), 0.97, date(2021, 3, 15)),
    ("MNWWF1", "SA1", "CP024", date(2020, 7, 1), date(2030, 6, 30), 1.02, date(2019, 11, 4)),
    ("DPLSF1", "QLD1", "CP023", date(2023, 1, 1), date(2037, 12, 31), 1.12, date(2022, 6, 20)),
]
ppa_rows, ppa_stats = [], {}
for duid, region_id, cp, start, end, price_ratio, traded in PPA_SPEC:
    gen = np.maximum(unit_energy[duid], 0)
    capacity = float(GENERATING_UNITS.set_index("duid").loc[duid, "registered_capacity_mw"])
    capture = float((market[region_id]["price"] * gen).sum() / gen.sum())
    capture_ratio = capture / float(market[region_id]["price"].mean())
    capacity_factor = float(gen.mean() / capacity)
    ppa_stats[duid] = dict(capture_ratio=capture_ratio, capacity_factor=capacity_factor, capacity=capacity, region_id=region_id)
    ppa_rows.append(dict(
        trade_id=f"PPA-{duid}", trade_date=traded, book_id="BK301", trader_name="Grace Okafor", counterparty_id=cp,
        instrument_type="PPA", profile="As Generated", buy_sell="Buy", region_id=region_id,
        delivery_period=f"{start:%b %Y} to {end:%b %Y}", delivery_start=start, delivery_end=end, volume_mw=capacity,
        contract_mwh=round(capacity * capacity_factor * 24 * ((end - start).days + 1), 2),
        price_aud_mwh=round(round(capture * price_ratio / 0.5) * 0.5, 2), strike_price_aud_mwh=None, linked_duid=duid,
        execution_venue="OTC bilateral", broker_name=None,
    ))
trades = pd.concat([trades, pd.DataFrame(ppa_rows)], ignore_index=True)
cancelled = (rng.random(len(trades)) < 0.015) & (trades.instrument_type != "PPA") & (trades.counterparty_id != "CP012")
trades["trade_status"] = np.where(cancelled, "Cancelled", np.where(trades.delivery_end < AS_OF_DATE, "Matured", "Live"))
trades["notional_aud"] = (trades.contract_mwh * trades.price_aud_mwh).round(2)
print(f"etrm_trade: {len(trades):,} rows")

# COMMAND ----------

# Step 8: ETRM daily valuations (mark-to-market) for every live trade, every business day.
val_days = [d.date() for d in pd.bdate_range(START_DATE - timedelta(days=7), AS_OF_DATE)]
pre_day = max(d for d in val_days if d < START_DATE)
val_days = [d for d in val_days if d >= pre_day]
val_index = pd.Index(val_days)
SIGN = {"Buy": 1.0, "Sell": -1.0}

rows = []
for t in trades[(trades.trade_status != "Cancelled") & (trades.instrument_type != "PPA")].itertuples():
    first, last = max(t.trade_date, pre_day), min(t.delivery_end, AS_OF_DATE)
    days = [d for d in val_days if first <= d <= last]
    if not days:
        continue
    total_days = (t.delivery_end - t.delivery_start).days + 1
    for d in days:
        remaining_frac = 1.0 if d < t.delivery_start else max((t.delivery_end - d).days, 0) / total_days
        remaining = t.contract_mwh * remaining_frac
        mid = max(d, t.delivery_start) + (t.delivery_end - max(d, t.delivery_start)) / 2
        df = math.exp(-DISCOUNT_RATE * max((mid - d).days, 0) / 365.25)
        market_price = float(curve_lookup[(d, t.region_id, t.profile, t.delivery_period)])
        mtm = SIGN[t.buy_sell] * (market_price - t.price_aud_mwh) * remaining * df
        delta = SIGN[t.buy_sell] * remaining * (0.35 if t.profile == "Cap $300" else 1.0)
        rows.append((d, t.trade_id, market_price, remaining, df, mtm, delta, t.trade_date))

# PPAs: value the remaining expected output against the base curve, adjusted for each unit's capture rate
for t in trades[trades.instrument_type == "PPA"].itertuples():
    s = ppa_stats[t.linked_duid]
    for d in val_days:
        dq = quarter_start(d)
        listed = {q: float(curve_lookup[(d, t.region_id, "Base", quarter_label(q))]) for q in quarters if 0 <= quarters_between(dq, q) <= 11}
        last_year = sorted(listed)[-4:]
        mtm = remaining_total = delta = 0.0
        q = dq
        while q <= t.delivery_end:
            q_end = min(quarter_end(q), t.delivery_end)
            start = max(q, d + timedelta(days=1), t.delivery_start)
            if start <= q_end:
                mwh = s["capacity"] * s["capacity_factor"] * 24 * ((q_end - start).days + 1)
                if q in listed:
                    base = listed[q]
                else:
                    same_season = [x for x in last_year if x.month == q.month][0]
                    base = listed[same_season] * 0.975 ** ((q.year - same_season.year))
                df = math.exp(-DISCOUNT_RATE * ((start - d).days + (q_end - start).days / 2) / 365.25)
                mtm += (s["capture_ratio"] * base - t.price_aud_mwh) * mwh * df
                remaining_total += mwh
                if q in listed:
                    delta += mwh * s["capture_ratio"]
            q = add_quarters(q, 1)
        market_price = s["capture_ratio"] * listed[dq]
        rows.append((d, t.trade_id, market_price, remaining_total, 1.0, mtm, delta, t.trade_date))

valuation = pd.DataFrame(rows, columns=["valuation_date", "trade_id", "market_price_aud_mwh", "remaining_mwh", "discount_factor", "mtm_aud", "delta_mwh", "trade_date"])
valuation = valuation.sort_values(["trade_id", "valuation_date"]).reset_index(drop=True)
valuation["mtm_change_aud"] = valuation.groupby("trade_id")["mtm_aud"].diff()
first_row = valuation["mtm_change_aud"].isna()
valuation.loc[first_row, "mtm_change_aud"] = np.where(valuation.loc[first_row, "trade_date"] == valuation.loc[first_row, "valuation_date"], valuation.loc[first_row, "mtm_aud"], 0.0)
valuation = valuation[valuation.valuation_date >= START_DATE].drop(columns="trade_date")
for c, digits in (("market_price_aud_mwh", 2), ("remaining_mwh", 2), ("discount_factor", 6), ("mtm_aud", 2), ("mtm_change_aud", 2), ("delta_mwh", 2)):
    valuation[c] = valuation[c].round(digits)
valuation = valuation.reset_index(drop=True)
print(f"etrm_trade_valuation: {len(valuation):,} rows")

# COMMAND ----------

# Step 9: ETRM monthly settlements (realised P&L) against the AEMO spot prices, for every fully delivered month.
month_starts = [m.date() for m in pd.date_range(START_DATE, END_DATE, freq="MS")]
complete_months = [m for m in month_starts if m >= START_DATE and (pd.Timestamp(m) + pd.offsets.MonthEnd(0)).date() < END_DATE]
interval_month = ts_start.to_period("M").to_timestamp().date
monthly = {}
for r in REGION_MODEL:
    pr = market[r]["price"]
    frame = pd.DataFrame({"month": interval_month, "p": pr / 12.0, "h": 1 / 12.0, "pk": is_peak, "cap": np.maximum(pr - CAP_STRIKE, 0) / 12.0})
    base = frame.groupby("month").agg(p=("p", "sum"), h=("h", "sum"), cap=("cap", "sum"))
    peak = frame[frame.pk].groupby("month").agg(p=("p", "sum"), h=("h", "sum"))
    monthly[r] = (base, peak)
ppa_monthly = {}
for duid, s in ppa_stats.items():
    gen = unit_dispatch.loc[unit_dispatch.duid == duid, "scada_mw"].to_numpy() / 12.0
    pr = market[s["region_id"]]["price"]
    ppa_monthly[duid] = pd.DataFrame({"month": interval_month, "mwh": gen, "value": gen * pr}).groupby("month").sum()

settle_rows = []
for t in trades[trades.trade_status != "Cancelled"].itertuples():
    for m in complete_months:
        m_end = (pd.Timestamp(m) + pd.offsets.MonthEnd(0)).date()
        if m < t.delivery_start or m_end > t.delivery_end:
            continue
        sign = SIGN[t.buy_sell]
        if t.instrument_type == "PPA":
            g = ppa_monthly[t.linked_duid].loc[m]
            mwh, spot_avg = g.mwh, g.value / g.mwh
            amount = sign * (g.value - t.price_aud_mwh * g.mwh)
        else:
            base, peak = monthly[t.region_id]
            stats = peak.loc[m] if t.profile == "Peak" else base.loc[m]
            mwh = t.volume_mw * stats.h
            spot_avg = stats.p / stats.h
            if t.profile == "Cap $300":
                amount = sign * t.volume_mw * (base.loc[m].cap - t.price_aud_mwh * stats.h)
            else:
                amount = sign * t.volume_mw * (stats.p - t.price_aud_mwh * stats.h)
        last_month = m == complete_months[-1]
        status = "Invoiced" if last_month else ("Disputed" if rng.random() < 0.01 else "Paid")
        due = (pd.Timestamp(m_end) + pd.Timedelta(days=20)).date()
        settle_rows.append((t.trade_id, m, round(mwh, 2), t.price_aud_mwh, round(spot_avg, 2), round(amount, 2), "Receive" if amount >= 0 else "Pay", status, due))

settlement = pd.DataFrame(settle_rows, columns=["trade_id", "settlement_month", "settled_mwh", "contract_price_aud_mwh", "average_spot_price_aud_mwh", "settlement_amount_aud", "payment_direction", "invoice_status", "payment_due_date"])
settlement = settlement.sort_values(["settlement_month", "trade_id"]).reset_index(drop=True)
settlement.insert(0, "settlement_id", [f"ST{200000 + i}" for i in range(len(settlement))])
print(f"etrm_trade_settlement: {len(settlement):,} rows")

# COMMAND ----------

# Step 10: risk limits. Credit limits and book position limits are set so the risk storylines show up on the latest date.
latest = valuation[valuation.valuation_date == AS_OF_DATE].merge(trades[["trade_id", "counterparty_id", "book_id"]], on="trade_id")
cp_mtm = latest.groupby("counterparty_id")["mtm_aud"].sum()
cp_peak = valuation.merge(trades[["trade_id", "counterparty_id"]], on="trade_id").groupby(["valuation_date", "counterparty_id"])["mtm_aud"].sum().clip(lower=0).groupby("counterparty_id").max()


def round_up(x, step):
    return float(math.ceil(max(x, step) / step) * step)


limits = COUNTERPARTIES.set_index("counterparty_id")["credit_limit_aud"].astype(float).to_dict()
for cp, peak_exposure in cp_peak.items():
    if cp == "CP001":
        continue
    limits[cp] = max(limits[cp], round_up(peak_exposure * 1.6, 5_000_000))
if cp_mtm.get("CP012", 0) > 2_000_000:
    limits["CP012"] = round_up(cp_mtm["CP012"] * 0.82, 1_000_000) - 1_000_000  # Spinifex Power: in breach
warning_types = COUNTERPARTIES.loc[COUNTERPARTIES.counterparty_type.isin(["Retailer", "Industrial", "Trading House", "Generator", "Gentailer"]) & (COUNTERPARTIES.counterparty_id != "CP012"), "counterparty_id"]
warning_cp = cp_mtm.reindex(warning_types).dropna()
if (warning_cp > 2_000_000).any():
    cp = warning_cp.idxmax()
    limits[cp] = round_up(warning_cp[cp] / 0.9, 1_000_000)  # close to its limit
COUNTERPARTIES["credit_limit_aud"] = COUNTERPARTIES["counterparty_id"].map(limits)

book_delta = valuation.merge(trades[["trade_id", "book_id"]], on="trade_id").groupby(["valuation_date", "book_id"])["delta_mwh"].sum()
book_limits = book_delta.abs().groupby("book_id").max().map(lambda x: round_up(x * 1.3, 50_000))
latest_delta = book_delta.xs(AS_OF_DATE, level="valuation_date").abs()
if "BK101" in latest_delta:
    book_limits["BK101"] = round_up(latest_delta["BK101"] / 0.93, 25_000)  # NSW Retail is close to its position limit
BOOKS["delta_limit_mwh"] = BOOKS["book_id"].map(book_limits).fillna(100_000.0)
print("Risk limits set.")

# COMMAND ----------

# Step 11: table definitions. Every table and column has a description; keys are declared so Genie and Catalog Explorer
# understand how the tables join.
T = {}  # table name -> (comment, columns [(name, type, nullable, comment)], primary key, foreign keys [(cols, ref table)])

T["aemo_region"] = (
    "Reference list of the five National Electricity Market (NEM) price regions, styled on AEMO region data. One row per region. Use region_name for display; region_id (for example NSW1) is the AEMO code that joins to the market and trading tables.",
    [
        ("region_id", "STRING", False, "AEMO region code and join key. Values: NSW1, QLD1, VIC1, SA1, TAS1."),
        ("region_name", "STRING", False, "Display name of the region, for example New South Wales. Use this in charts and answers instead of the code."),
        ("state_code", "STRING", False, "Short state abbreviation: NSW, QLD, VIC, SA or TAS."),
        ("reference_node", "STRING", False, "Regional reference node where the regional spot price is set."),
        ("latitude", "DOUBLE", False, "Approximate latitude of the regional reference node, for map visuals."),
        ("longitude", "DOUBLE", False, "Approximate longitude of the regional reference node, for map visuals."),
        ("has_exchange_futures", "BOOLEAN", False, "True if exchange-traded electricity futures and forward curves exist for the region (all regions except Tasmania)."),
    ],
    ["region_id"], [],
)
T["aemo_generating_unit"] = (
    "Registration details of the generating units in the trading desk's portfolio, styled on the AEMO Generators and Scheduled Loads list. One row per dispatchable unit identifier (DUID). Includes owned plant and wind and solar farms contracted under power purchase agreements (PPAs). Station names are fictional.",
    [
        ("duid", "STRING", False, "Dispatchable unit identifier (DUID): AEMO's unique code for a generating unit. Join key to aemo_unit_dispatch and to etrm_trade.linked_duid."),
        ("station_name", "STRING", False, "Power station name. Several units (DUIDs) can belong to one station."),
        ("region_id", "STRING", False, "NEM region the unit is located in and paid the spot price of."),
        ("fuel_type", "STRING", False, "Primary fuel or energy source: Black Coal, Natural Gas, Hydro, Battery Storage, Wind or Solar."),
        ("technology_type", "STRING", False, "Generation technology, for example Open Cycle Gas Turbine (a fast-start peaker) or Combined Cycle Gas Turbine."),
        ("classification", "STRING", False, "AEMO dispatch classification: Scheduled (bids into dispatch) or Semi-scheduled (variable wind and solar)."),
        ("dispatch_type", "STRING", False, "Generator, or Bidirectional unit for batteries and pumped hydro that can both generate and consume power."),
        ("registered_capacity_mw", "DOUBLE", False, "Maximum registered output in megawatts (MW)."),
        ("storage_capacity_mwh", "DOUBLE", True, "Energy storage capacity in MWh for batteries and pumped hydro; empty for other units."),
        ("min_stable_generation_mw", "DOUBLE", False, "Lowest stable output while running, MW. Coal units stay at or above this level even when prices are negative."),
        ("srmc_aud_mwh", "DOUBLE", False, "Estimated short-run marginal cost (fuel plus variable cost), AUD per MWh. A unit tends to run when the spot price is above it."),
        ("emissions_intensity_t_mwh", "DOUBLE", False, "Scope 1 emissions intensity in tonnes CO2-e per MWh generated."),
        ("ownership_type", "STRING", False, "Owned (the company's own plant) or Contracted (PPA) (output bought from a third-party wind or solar farm)."),
        ("commissioning_year", "INT", False, "Year the unit started commercial operation."),
        ("latitude", "DOUBLE", False, "Approximate latitude of the station, for map visuals."),
        ("longitude", "DOUBLE", False, "Approximate longitude of the station, for map visuals."),
    ],
    ["duid"], [(["region_id"], "aemo_region")],
)
T["aemo_dispatch_region"] = (
    "5-minute market outcomes for each NEM region, styled on AEMO MMS DISPATCHPRICE and DISPATCHREGIONSUM. One row per region per 5-minute dispatch interval. Prices are in AUD per MWh and the NEM settles every 5 minutes, so the average of rrp_aud_mwh over a period is the time-weighted average spot price.",
    [
        ("settlement_date", "TIMESTAMP_NTZ", False, "End time of the 5-minute dispatch interval in NEM market time (AEST, UTC+10, no daylight saving). AEMO labels intervals by their end time, so 18:05 covers 18:00 to 18:05."),
        ("trading_date", "DATE", False, "Calendar date of the interval in market time (based on the interval start). Use this for daily, weekly and monthly analysis."),
        ("hour_of_day", "INT", False, "Hour of day (0 to 23) in which the interval starts, in market time. Use for intraday profiles such as the solar duck curve."),
        ("is_peak_period", "BOOLEAN", False, "True for the peak period used by peak swaps and futures: 07:00 to 22:00, Monday to Friday (public holidays are not excluded in this dataset)."),
        ("region_id", "STRING", False, "AEMO region code. Join to aemo_region for the region name."),
        ("rrp_aud_mwh", "DOUBLE", False, "Regional reference price (RRP): the 5-minute spot price in AUD per MWh, also called the spot price, pool price or energy price. Ranges from the market floor of -1,000 to the market price cap. Prices above 300 are usually called price spikes; prices below 0 are negative prices."),
        ("total_demand_mw", "DOUBLE", False, "Demand met by scheduled and semi-scheduled generation (AEMO TOTALDEMAND), MW. Rooftop solar reduces it in the middle of the day."),
        ("rooftop_solar_mw", "DOUBLE", False, "Estimated rooftop (behind-the-meter) solar output, MW."),
        ("wind_generation_mw", "DOUBLE", False, "Total output of utility-scale wind farms in the region, MW."),
        ("utility_solar_mw", "DOUBLE", False, "Total output of utility-scale solar farms in the region, MW."),
        ("available_generation_mw", "DOUBLE", False, "Total generation capacity available in the region, MW. Available generation minus total demand shows how tight supply is."),
        ("net_interchange_mw", "DOUBLE", False, "Net interconnector flow, MW. Positive means the region is exporting to its neighbours; negative means importing (AEMO NETINTERCHANGE convention)."),
    ],
    ["settlement_date", "region_id"], [(["region_id"], "aemo_region")],
)
T["aemo_unit_dispatch"] = (
    "5-minute output of each unit in the portfolio, styled on AEMO DISPATCH_UNIT_SCADA and DISPATCHLOAD. One row per unit (DUID) per 5-minute interval. Join to aemo_generating_unit on duid; to get the spot price a unit earned, also join aemo_dispatch_region on settlement_date and the unit's region_id.",
    [
        ("settlement_date", "TIMESTAMP_NTZ", False, "End time of the 5-minute dispatch interval in NEM market time (AEST, UTC+10)."),
        ("trading_date", "DATE", False, "Calendar date of the interval in market time."),
        ("duid", "STRING", False, "Dispatchable unit identifier. Join to aemo_generating_unit for the station, fuel type and region."),
        ("scada_mw", "DOUBLE", False, "Metered output at the end of the interval, MW. Negative means the unit is consuming power (battery charging or pumped hydro pumping). This is a rate, so do not sum it; sum energy_mwh instead."),
        ("available_mw", "DOUBLE", False, "Capacity the unit could have produced, MW. Zero during outages. For wind and solar it is the weather-driven potential output, so available_mw minus scada_mw is curtailment."),
        ("energy_mwh", "DOUBLE", False, "Energy produced in the interval in MWh (scada_mw divided by 12). Sum this column for generation volumes."),
    ],
    ["settlement_date", "duid"], [(["duid"], "aemo_generating_unit")],
)
T["etrm_book"] = (
    "Trading book hierarchy from the ETRM, styled on Allegro. Each trade belongs to one book; books roll up to portfolios and desks. One row per book.",
    [
        ("book_id", "STRING", False, "Book code and join key to etrm_trade."),
        ("book_name", "STRING", False, "Book display name, for example NSW Retail Load Hedge."),
        ("portfolio", "STRING", False, "Portfolio the book rolls up to, for example Retail Hedging or Thermal Generation."),
        ("desk", "STRING", False, "Trading desk responsible for the book: the top level of the book hierarchy."),
        ("strategy", "STRING", False, "Plain-English purpose of the book."),
        ("book_owner", "STRING", False, "Trader accountable for the book (fictional)."),
        ("region_focus", "STRING", False, "State the book trades in, or Multi-region."),
        ("delta_limit_mwh", "DOUBLE", False, "Risk limit on the absolute net delta position of the book in MWh. Compare with the sum of delta_mwh in etrm_trade_valuation."),
    ],
    ["book_id"], [],
)
T["etrm_counterparty"] = (
    "Counterparties the desk trades with, including the futures clearing house. One row per counterparty. Names are fictional apart from the clearing house. Credit limits are used to monitor credit exposure.",
    [
        ("counterparty_id", "STRING", False, "Counterparty code and join key to etrm_trade."),
        ("counterparty_name", "STRING", False, "Legal name of the counterparty."),
        ("counterparty_type", "STRING", False, "Type of business: Bank, Trading House, Generator, Gentailer, Retailer, Industrial, Renewable Developer, Government or Clearing House."),
        ("credit_rating", "STRING", False, "Long-term credit rating (S&P style, for example BBB+), or NR for not rated."),
        ("credit_limit_aud", "DOUBLE", False, "Maximum credit exposure allowed to the counterparty, AUD."),
        ("master_agreement", "STRING", False, "Agreement that governs the trades: ISDA, AFMA, or ASX Operating Rules for exchange futures."),
        ("is_exchange_cleared", "BOOLEAN", False, "True for the futures clearing house, where exposure is managed by daily margining."),
        ("country", "STRING", False, "Country of incorporation."),
    ],
    ["counterparty_id"], [],
)
T["etrm_trade"] = (
    "Trade (deal) capture records from the ETRM, styled on Allegro. One row per trade. Covers electricity swaps, $300 caps, ASX futures and renewable power purchase agreements (PPAs). Directions are from the desk's point of view.",
    [
        ("trade_id", "STRING", False, "Unique trade (deal) number."),
        ("trade_date", "DATE", False, "Date the trade was executed."),
        ("book_id", "STRING", False, "Book the trade belongs to. Join to etrm_book."),
        ("trader_name", "STRING", False, "Trader who executed the trade (fictional)."),
        ("counterparty_id", "STRING", False, "Counterparty of the trade. Join to etrm_counterparty."),
        ("instrument_type", "STRING", False, "Contract type: Swap (fixed-for-floating), Cap (pays out when spot is above the 300 strike), Future (exchange-traded on ASX), or PPA (power purchase agreement on a specific unit's output)."),
        ("profile", "STRING", False, "Delivery shape: Base (all hours), Peak (07:00 to 22:00 on weekdays), Cap $300 (all hours with a 300 AUD/MWh strike), or As Generated (PPA volume follows the linked unit's output)."),
        ("buy_sell", "STRING", False, "Buy or Sell. A Buy position gains when prices rise; a Sell position gains when prices fall."),
        ("region_id", "STRING", False, "NEM region whose spot price the trade settles against. Join to aemo_region."),
        ("delivery_period", "STRING", False, "Readable delivery period, for example Q3 2026 for a calendar quarter (Q1 = Jan to Mar, Q2 = Apr to Jun, Q3 = Jul to Sep, Q4 = Oct to Dec). Matches etrm_forward_curve.contract_period."),
        ("delivery_start", "DATE", False, "First day of delivery."),
        ("delivery_end", "DATE", False, "Last day of delivery."),
        ("volume_mw", "DOUBLE", False, "Contracted volume in MW. For PPAs this is the unit's capacity; the settled volume follows its actual output."),
        ("contract_mwh", "DOUBLE", False, "Total contracted energy over the delivery period, MWh (expected energy for PPAs)."),
        ("price_aud_mwh", "DOUBLE", False, "Fixed price in AUD per MWh: the swap or futures price, the premium for caps, or the PPA price."),
        ("strike_price_aud_mwh", "DOUBLE", True, "Strike price of caps (300 AUD/MWh); empty for other instruments."),
        ("linked_duid", "STRING", True, "For PPAs, the DUID of the wind or solar unit whose output is contracted; empty otherwise. Join to aemo_generating_unit."),
        ("execution_venue", "STRING", False, "Where the trade was done: ASX24 (exchange), OTC broker, or OTC bilateral."),
        ("broker_name", "STRING", True, "Broker used for OTC broker trades; empty otherwise."),
        ("trade_status", "STRING", False, "Live (delivery not finished), Matured (delivery complete) or Cancelled (excluded from valuations and settlements)."),
        ("notional_aud", "DOUBLE", False, "Contract value at the trade price (contract_mwh times price_aud_mwh), AUD."),
    ],
    ["trade_id"],
    [(["book_id"], "etrm_book"), (["counterparty_id"], "etrm_counterparty"), (["region_id"], "aemo_region"), (["linked_duid"], "aemo_generating_unit")],
)
T["etrm_forward_curve"] = (
    "Daily end-of-day forward price curves used to value trades, styled on Allegro price curves. One row per curve date, region, profile and contract quarter. Tasmania has no curve.",
    [
        ("curve_date", "DATE", False, "Business date of the end-of-day curve."),
        ("curve_name", "STRING", False, "Curve label, for example NSW Base Quarterly."),
        ("region_id", "STRING", False, "NEM region of the curve. Join to aemo_region."),
        ("profile", "STRING", False, "Base, Peak or Cap $300."),
        ("contract_period", "STRING", False, "Contract quarter, for example Q1 2027. Matches etrm_trade.delivery_period."),
        ("period_start", "DATE", False, "First day of the contract quarter."),
        ("period_end", "DATE", False, "Last day of the contract quarter."),
        ("price_aud_mwh", "DOUBLE", False, "Forward price for the contract quarter in AUD per MWh. For Cap $300 it is the cap premium."),
        ("price_source", "STRING", False, "Exchange settlement for the liquid first eight quarters, Broker composite for later quarters."),
    ],
    ["curve_date", "region_id", "profile", "contract_period"], [(["region_id"], "aemo_region")],
)
T["etrm_trade_valuation"] = (
    "Daily mark-to-market (MTM) valuation of every live trade, styled on Allegro valuation results. One row per trade per business day. Values are in AUD from the desk's point of view; a positive MTM means the trade is in the money. Join to etrm_trade on trade_id for book, counterparty and instrument details.",
    [
        ("valuation_date", "DATE", False, "Business date of the valuation."),
        ("trade_id", "STRING", False, "Trade being valued. Join to etrm_trade."),
        ("market_price_aud_mwh", "DOUBLE", False, "Forward curve price used for the valuation, AUD per MWh (capture-adjusted base price for PPAs)."),
        ("remaining_mwh", "DOUBLE", False, "Energy still to be delivered after the valuation date, MWh."),
        ("discount_factor", "DOUBLE", False, "Discount factor applied to future cash flows."),
        ("mtm_aud", "DOUBLE", False, "Unrealised mark-to-market value in AUD: (market price minus trade price) times remaining MWh times discount factor, reversed for Sell trades. Sum across trades for book or portfolio MTM."),
        ("mtm_change_aud", "DOUBLE", False, "Change in MTM since the previous business day, AUD: the daily unrealised P&L. On the trade date it is the day-one P&L."),
        ("delta_mwh", "DOUBLE", False, "Price sensitivity expressed as equivalent energy, MWh. Positive means long (gains if prices rise), negative means short. Sum for the net position."),
    ],
    ["valuation_date", "trade_id"], [(["trade_id"], "etrm_trade")],
)
T["etrm_trade_settlement"] = (
    "Monthly cash settlement of delivered trades against AEMO spot prices: the realised P&L. One row per trade per fully delivered calendar month. Positive amounts are received by the desk; negative amounts are paid.",
    [
        ("settlement_id", "STRING", False, "Unique settlement line number."),
        ("trade_id", "STRING", False, "Trade being settled. Join to etrm_trade."),
        ("settlement_month", "DATE", False, "First day of the delivery month being settled."),
        ("settled_mwh", "DOUBLE", False, "Energy settled in the month, MWh."),
        ("contract_price_aud_mwh", "DOUBLE", False, "Trade price (the premium for caps), AUD per MWh."),
        ("average_spot_price_aud_mwh", "DOUBLE", False, "Average spot price over the trade's profile hours in the month (generation-weighted for PPAs), AUD per MWh."),
        ("settlement_amount_aud", "DOUBLE", False, "Realised P&L for the month in AUD. Swaps and futures: (spot minus fixed price) times MWh for Buy, reversed for Sell. Caps: payouts above the 300 strike minus the premium. PPAs: (spot minus PPA price) times generated MWh."),
        ("payment_direction", "STRING", False, "Receive or Pay."),
        ("invoice_status", "STRING", False, "Paid, Invoiced (latest month, not yet due) or Disputed."),
        ("payment_due_date", "DATE", False, "Date the settlement payment is due."),
    ],
    ["settlement_id"], [(["trade_id"], "etrm_trade")],
)
T["gold_market_daily"] = (
    "Dashboard-ready daily market summary for each NEM region, built from aemo_dispatch_region and aemo_region. One row per region per day.",
    [
        ("trading_date", "DATE", False, "Calendar date in market time."),
        ("region_id", "STRING", False, "AEMO region code."),
        ("region_name", "STRING", False, "Region display name."),
        ("average_price_aud_mwh", "DOUBLE", False, "Time-weighted average spot price for the day, AUD per MWh."),
        ("demand_weighted_price_aud_mwh", "DOUBLE", False, "Demand-weighted average spot price for the day, AUD per MWh: what an average customer load paid."),
        ("min_price_aud_mwh", "DOUBLE", False, "Lowest 5-minute spot price of the day."),
        ("max_price_aud_mwh", "DOUBLE", False, "Highest 5-minute spot price of the day."),
        ("price_spike_intervals", "INT", False, "Number of 5-minute intervals with a spot price above 300 AUD/MWh."),
        ("negative_price_intervals", "INT", False, "Number of 5-minute intervals with a spot price below 0."),
        ("average_demand_mw", "DOUBLE", False, "Average total demand, MW."),
        ("peak_demand_mw", "DOUBLE", False, "Highest 5-minute total demand of the day, MW."),
        ("energy_demand_mwh", "DOUBLE", False, "Total energy demand for the day, MWh."),
        ("renewable_share_pct", "DOUBLE", False, "Share of underlying demand met by wind, utility solar and rooftop solar, percent."),
    ],
    ["trading_date", "region_id"], [],
)
T["gold_book_pnl_daily"] = (
    "Dashboard-ready daily P&L and position for each trading book, built from etrm_trade_valuation, etrm_trade_settlement, etrm_trade and etrm_book. One row per book per business day.",
    [
        ("valuation_date", "DATE", False, "Business date of the valuation."),
        ("book_id", "STRING", False, "Book code."),
        ("book_name", "STRING", False, "Book display name."),
        ("portfolio", "STRING", False, "Portfolio the book rolls up to."),
        ("desk", "STRING", False, "Desk the book belongs to."),
        ("live_trades", "INT", False, "Number of trades valued on the date."),
        ("unrealised_mtm_aud", "DOUBLE", False, "Total mark-to-market of the book's trades, AUD."),
        ("daily_mtm_change_aud", "DOUBLE", False, "Daily change in MTM (daily unrealised P&L), AUD."),
        ("realised_pnl_fytd_aud", "DOUBLE", False, "Realised (settled) P&L in the current Australian financial year (from 1 July) for months completed before the valuation date, AUD."),
        ("net_delta_mwh", "DOUBLE", False, "Net delta position of the book, MWh. Positive = long, negative = short."),
        ("delta_limit_mwh", "DOUBLE", False, "Position limit for the book, MWh."),
        ("delta_limit_utilisation_pct", "DOUBLE", False, "Absolute net delta as a percentage of the position limit."),
    ],
    ["valuation_date", "book_id"], [],
)
T["gold_counterparty_exposure_daily"] = (
    "Dashboard-ready daily credit exposure for each counterparty, built from etrm_trade_valuation, etrm_trade and etrm_counterparty. One row per counterparty per business day.",
    [
        ("valuation_date", "DATE", False, "Business date of the valuation."),
        ("counterparty_id", "STRING", False, "Counterparty code."),
        ("counterparty_name", "STRING", False, "Counterparty name."),
        ("counterparty_type", "STRING", False, "Type of business."),
        ("credit_rating", "STRING", False, "Credit rating."),
        ("credit_limit_aud", "DOUBLE", False, "Credit limit, AUD."),
        ("live_trades", "INT", False, "Number of trades valued with the counterparty on the date."),
        ("net_mtm_aud", "DOUBLE", False, "Net mark-to-market across all trades with the counterparty, AUD."),
        ("credit_exposure_aud", "DOUBLE", False, "Credit exposure: the positive part of net MTM, which is what the counterparty would owe us if it defaulted today, AUD."),
        ("limit_utilisation_pct", "DOUBLE", False, "Credit exposure as a percentage of the credit limit."),
        ("limit_status", "STRING", False, "Within limit (below 80 percent), Warning (80 to 100 percent), Breach (above 100 percent) or Exchange cleared."),
    ],
    ["valuation_date", "counterparty_id"], [],
)

# COMMAND ----------

# Step 12: write the tables to Unity Catalog.
from pyspark.sql import types as St

SPARK_TYPES = {"STRING": St.StringType(), "DOUBLE": St.DoubleType(), "INT": St.IntegerType(), "BOOLEAN": St.BooleanType(), "DATE": St.DateType(), "TIMESTAMP_NTZ": St.TimestampNTZType()}
DROP_ORDER = [
    "gold_counterparty_exposure_daily", "gold_book_pnl_daily", "gold_market_daily", "etrm_trade_settlement", "etrm_trade_valuation",
    "etrm_forward_curve", "aemo_unit_dispatch", "aemo_dispatch_region", "etrm_trade", "aemo_generating_unit", "etrm_book", "etrm_counterparty", "aemo_region",
]


def sql_text(s):
    return s.replace("\\", "\\\\").replace("'", "\\'")


def create_table(name):
    comment, columns, pk, fks = T[name]
    lines = [f"  `{c}` {t}{'' if nullable else ' NOT NULL'} COMMENT '{sql_text(cm)}'" for c, t, nullable, cm in columns]
    lines.append(f"  CONSTRAINT {name}_pk PRIMARY KEY ({', '.join(pk)})")
    for cols, ref in fks:
        lines.append(f"  CONSTRAINT {name}_{cols[0]}_fk FOREIGN KEY ({', '.join(cols)}) REFERENCES `{CATALOG}`.`{SCHEMA}`.`{ref}`")
    spark.sql(f"CREATE TABLE `{CATALOG}`.`{SCHEMA}`.`{name}` (\n" + ",\n".join(lines) + f"\n) COMMENT '{sql_text(comment)}'")


def write_table(name, pdf, chunk_rows=400_000):
    _, columns, _, _ = T[name]
    names = [c for c, *_ in columns]
    schema = St.StructType([St.StructField(c, SPARK_TYPES[t], True) for c, t, *_ in columns])
    pdf = pdf[names].copy()
    for c, t, *_ in columns:
        if t == "INT":
            pdf[c] = pdf[c].astype("int32")
        elif t == "DOUBLE":
            pdf[c] = pdf[c].astype("float64")
        elif t == "TIMESTAMP_NTZ":
            pdf[c] = pd.to_datetime(pdf[c])
        elif t in ("STRING",):
            pdf[c] = pdf[c].astype(object).where(pdf[c].notna(), None)
    create_table(name)
    for i in range(0, len(pdf), chunk_rows):
        spark.createDataFrame(pdf.iloc[i : i + chunk_rows], schema=schema).write.mode("append").saveAsTable(f"`{CATALOG}`.`{SCHEMA}`.`{name}`")
    print(f"  {name}: {len(pdf):,} rows")


for name in DROP_ORDER:
    spark.sql(f"DROP TABLE IF EXISTS `{CATALOG}`.`{SCHEMA}`.`{name}`")

write_table("aemo_region", REGIONS)
write_table("aemo_generating_unit", GENERATING_UNITS)
write_table("etrm_book", BOOKS)
write_table("etrm_counterparty", COUNTERPARTIES)
write_table("etrm_trade", trades)
write_table("aemo_dispatch_region", dispatch_region)
write_table("aemo_unit_dispatch", unit_dispatch)
write_table("etrm_forward_curve", forward_curve)
write_table("etrm_trade_valuation", valuation)
write_table("etrm_trade_settlement", settlement)

# COMMAND ----------

# Step 13: build the dashboard-ready gold tables with SQL.
FQ = f"`{CATALOG}`.`{SCHEMA}`"
for name in ("gold_market_daily", "gold_book_pnl_daily", "gold_counterparty_exposure_daily"):
    create_table(name)

spark.sql(f"""
INSERT INTO {FQ}.gold_market_daily
SELECT
  d.trading_date,
  d.region_id,
  r.region_name,
  ROUND(AVG(d.rrp_aud_mwh), 2),
  ROUND(SUM(d.rrp_aud_mwh * d.total_demand_mw) / SUM(d.total_demand_mw), 2),
  MIN(d.rrp_aud_mwh),
  MAX(d.rrp_aud_mwh),
  CAST(COUNT_IF(d.rrp_aud_mwh > 300) AS INT),
  CAST(COUNT_IF(d.rrp_aud_mwh < 0) AS INT),
  ROUND(AVG(d.total_demand_mw), 1),
  ROUND(MAX(d.total_demand_mw), 1),
  ROUND(SUM(d.total_demand_mw) / 12, 1),
  ROUND(100 * SUM(d.wind_generation_mw + d.utility_solar_mw + d.rooftop_solar_mw) / SUM(d.total_demand_mw + d.rooftop_solar_mw), 1)
FROM {FQ}.aemo_dispatch_region d
JOIN {FQ}.aemo_region r ON r.region_id = d.region_id
GROUP BY d.trading_date, d.region_id, r.region_name
""")

spark.sql(f"""
INSERT INTO {FQ}.gold_book_pnl_daily
WITH val AS (
  SELECT v.valuation_date, t.book_id, COUNT(*) AS live_trades, SUM(v.mtm_aud) AS mtm, SUM(v.mtm_change_aud) AS mtm_change, SUM(v.delta_mwh) AS delta
  FROM {FQ}.etrm_trade_valuation v JOIN {FQ}.etrm_trade t ON t.trade_id = v.trade_id
  GROUP BY v.valuation_date, t.book_id
),
settled AS (
  SELECT t.book_id, s.settlement_month, SUM(s.settlement_amount_aud) AS amount
  FROM {FQ}.etrm_trade_settlement s JOIN {FQ}.etrm_trade t ON t.trade_id = s.trade_id
  GROUP BY t.book_id, s.settlement_month
),
realised AS (
  SELECT val.valuation_date, val.book_id, COALESCE(SUM(settled.amount), 0) AS realised_fytd
  FROM val LEFT JOIN settled
    ON settled.book_id = val.book_id
   AND LAST_DAY(settled.settlement_month) < val.valuation_date
   AND settled.settlement_month >= MAKE_DATE(YEAR(val.valuation_date) - IF(MONTH(val.valuation_date) < 7, 1, 0), 7, 1)
  GROUP BY val.valuation_date, val.book_id
)
SELECT
  val.valuation_date, b.book_id, b.book_name, b.portfolio, b.desk, CAST(val.live_trades AS INT),
  ROUND(val.mtm, 2), ROUND(val.mtm_change, 2), ROUND(realised.realised_fytd, 2), ROUND(val.delta, 2), b.delta_limit_mwh,
  ROUND(100 * ABS(val.delta) / b.delta_limit_mwh, 1)
FROM val
JOIN {FQ}.etrm_book b ON b.book_id = val.book_id
JOIN realised ON realised.valuation_date = val.valuation_date AND realised.book_id = val.book_id
""")

spark.sql(f"""
INSERT INTO {FQ}.gold_counterparty_exposure_daily
WITH cp AS (
  SELECT v.valuation_date, t.counterparty_id, COUNT(*) AS live_trades, SUM(v.mtm_aud) AS net_mtm
  FROM {FQ}.etrm_trade_valuation v JOIN {FQ}.etrm_trade t ON t.trade_id = v.trade_id
  GROUP BY v.valuation_date, t.counterparty_id
)
SELECT
  cp.valuation_date, c.counterparty_id, c.counterparty_name, c.counterparty_type, c.credit_rating, c.credit_limit_aud,
  CAST(cp.live_trades AS INT), ROUND(cp.net_mtm, 2), ROUND(GREATEST(cp.net_mtm, 0), 2),
  ROUND(100 * GREATEST(cp.net_mtm, 0) / c.credit_limit_aud, 1),
  CASE
    WHEN c.is_exchange_cleared THEN 'Exchange cleared'
    WHEN GREATEST(cp.net_mtm, 0) > c.credit_limit_aud THEN 'Breach'
    WHEN GREATEST(cp.net_mtm, 0) >= 0.8 * c.credit_limit_aud THEN 'Warning'
    ELSE 'Within limit'
  END
FROM cp JOIN {FQ}.etrm_counterparty c ON c.counterparty_id = cp.counterparty_id
""")
print("Gold tables built.")

# COMMAND ----------

# Step 14: summary. You should see 13 tables with descriptions.
summary = []
for name in reversed(DROP_ORDER):
    rows = spark.table(f"`{CATALOG}`.`{SCHEMA}`.`{name}`").count()
    summary.append((name, rows, T[name][0].split(". ")[0] + "."))
display(spark.createDataFrame(summary, "table_name STRING, row_count BIGINT, description STRING"))
print(f"Done. Your data is in {CATALOG}.{SCHEMA}. Data covers {START_DATE} to {END_DATE - timedelta(days=1)}; valuations as of {AS_OF_DATE}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next steps
# MAGIC 1. Open **Catalog** in the left sidebar, expand **nem_workshop**, then **trading_desk**, and click a table. Look at the **Overview** (descriptions), **Sample Data** and **Lineage** tabs.
# MAGIC 2. Go back to the workshop playbook and start **Part 2: build your first dashboard**.
# MAGIC
# MAGIC The data hides a few stories for you to find: a summer heatwave, a winter price squeeze, spring negative prices, a
# MAGIC power station outage, a book that is close to its position limit and a counterparty over its credit limit.
